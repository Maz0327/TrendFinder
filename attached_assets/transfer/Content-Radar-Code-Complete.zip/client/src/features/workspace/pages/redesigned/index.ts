export { DashboardPage } from './DashboardPage';
export { SignalsPage } from './SignalsPage';
export { CapturePage } from './CapturePage';
export { BriefsPage } from './BriefsPage';
export { InsightsPage } from './InsightsPage';