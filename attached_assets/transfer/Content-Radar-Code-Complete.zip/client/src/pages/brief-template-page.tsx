import React from 'react';
import { BriefTemplateEngine } from '@/components/brief-template-engine';

export default function BriefTemplatePage() {
  return <BriefTemplateEngine />;
}