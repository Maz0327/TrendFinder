import React from 'react';
import { ProjectGallery } from '@/components/project-gallery';

export default function ProjectGalleryPage() {
  return <ProjectGallery />;
}