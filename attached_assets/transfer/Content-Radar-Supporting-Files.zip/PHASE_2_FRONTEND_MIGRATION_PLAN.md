# Phase 2: Frontend Migration & UI/UX Overhaul

## Overview
Migrating the frontend to use the new 6-table schema while implementing a modern 2025 UI/UX design.

## Migration Strategy

### 1. Schema Migration (Week 1)
- Update all API calls to use new consolidated endpoints
- Replace signal → capture terminology throughout
- Update data models to match new schema structure
- Fix TypeScript types for new data shapes

### 2. Component Modernization (Week 1-2)
- Upgrade to latest shadcn/ui components
- Implement consistent loading states
- Add proper error boundaries
- Create reusable compound components

### 3. UI/UX Overhaul (Week 2-3)
- **Navigation**: Implement new 5-tab workspace design
  - Today's Briefing
  - Explore Signals
  - New Signal Capture
  - Strategic Brief Lab
  - Manage
- **Design System**:
  - Professional gradients
  - Dark mode by default
  - Reduced header (48px)
  - Collapsible sidebar (192px → 48px)
  - Touch-optimized mobile views
- **Performance**:
  - Lazy loading for all routes
  - Virtual scrolling for large lists
  - Optimistic UI updates
  - Progressive enhancement

### 4. Chrome Extension Rebuild (Week 3-4)
- Modern manifest V3
- Professional UI matching main app
- Voice notes integration
- Smart screenshot capture
- Auto-tagging system
- Project assignment workflow

## Technical Approach

### API Layer Updates
```typescript
// Old: Multiple service calls
const signal = await signalService.getSignal(id);
const analysis = await analysisService.getTruthAnalysis(signal.id);

// New: Single consolidated call
const capture = await api.captures.get(id); // Includes analysis
```

### Data Model Migration
```typescript
// Old: Signal-based model
interface Signal {
  id: string;
  url: string;
  truthAnalysis?: TruthAnalysis;
  // ... 60+ fields
}

// New: Capture-based model
interface Capture {
  id: string;
  sourceUrl: string;
  content: string;
  analysis: Analysis;
  status: 'capture' | 'potential' | 'signal' | 'validated';
  // ... clean, focused fields
}
```

### Component Architecture
```typescript
// Feature-based folder structure
src/
  features/
    captures/
      components/
      hooks/
      api/
    briefs/
      components/
      hooks/
      api/
    workspace/
      components/
      hooks/
      api/
```

## Success Metrics
- [ ] All API calls using new endpoints
- [ ] Zero TypeScript errors
- [ ] Consistent 60fps scrolling
- [ ] < 3s initial load time
- [ ] 100% mobile responsive
- [ ] Chrome extension < 10MB

## Risk Mitigation
- Keep OLD_SYSTEM_FILES for reference
- Implement feature flags for gradual rollout
- Maintain backward compatibility layer
- Comprehensive E2E testing

## Next Steps
1. Audit current component usage
2. Create new API client
3. Update core data hooks
4. Begin component migration
5. Implement new navigation