// Test Bright Data browser automation directly
import puppeteer from 'puppeteer-core';

async function testBrightDataBrowser() {
  console.log('Testing Bright Data browser automation...');
  
  try {
    // Test proxy endpoint connection
    const proxyEndpoint = process.env.BRIGHT_DATA_PROXY_ENDPOINT;
    const username = process.env.BRIGHT_DATA_USERNAME;
    const password = process.env.BRIGHT_DATA_PASSWORD;
    
    console.log('Proxy endpoint:', proxyEndpoint ? 'Set' : 'Missing');
    console.log('Username:', username ? 'Set' : 'Missing');
    console.log('Password:', password ? 'Set' : 'Missing');
    
    if (!proxyEndpoint || !username || !password) {
      console.log('❌ Missing Bright Data browser credentials');
      return false;
    }
    
    // Try to connect to proxy
    const browser = await puppeteer.connect({
      browserWSEndpoint: `wss://${username}:${password}@${proxyEndpoint}`
    });
    
    console.log('✅ Bright Data browser connection successful');
    
    // Test basic navigation
    const page = await browser.newPage();
    await page.goto('https://httpbin.org/ip', { waitUntil: 'networkidle0' });
    const content = await page.content();
    
    console.log('✅ Page navigation successful');
    console.log('IP response:', content.includes('origin') ? 'Got IP data' : 'No IP data');
    
    await browser.close();
    return true;
    
  } catch (error) {
    console.log('❌ Bright Data browser test failed:', error.message);
    return false;
  }
}

// Test direct API access
async function testBrightDataAPI() {
  console.log('\nTesting Bright Data API...');
  
  try {
    const apiKey = process.env.BRIGHT_DATA_API_KEY;
    console.log('API Key:', apiKey ? 'Set' : 'Missing');
    
    if (!apiKey) {
      console.log('❌ Missing Bright Data API key');
      return false;
    }
    
    // Test API endpoint
    const response = await fetch('https://api.brightdata.com/datasets', {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (response.ok) {
      console.log('✅ Bright Data API connection successful');
      const data = await response.json();
      console.log('Available datasets:', data?.datasets?.length || 'Unknown count');
      return true;
    } else {
      console.log('❌ Bright Data API failed:', response.status, response.statusText);
      return false;
    }
    
  } catch (error) {
    console.log('❌ Bright Data API test failed:', error.message);
    return false;
  }
}

async function runTests() {
  console.log('=== Bright Data Connectivity Test ===\n');
  
  const browserResult = await testBrightDataBrowser();
  const apiResult = await testBrightDataAPI();
  
  console.log('\n=== Summary ===');
  console.log('Browser automation:', browserResult ? '✅ Working' : '❌ Failed');
  console.log('API access:', apiResult ? '✅ Working' : '❌ Failed');
  
  if (browserResult || apiResult) {
    console.log('\n✅ Bright Data is ready for use');
  } else {
    console.log('\n❌ Bright Data needs configuration');
  }
}

runTests().catch(console.error);