# Comprehensive Platform Rebuild Plan 2025

## Executive Summary

This document outlines the complete rebuild strategy for transforming our content intelligence platform from a 73-service architectural disaster into a clean, professional, and scalable system. The plan incorporates all learnings from Content Radar's successful migration, 2025 UI/UX trends, and preserves our unique competitive advantages.

**Key Outcomes:**
- 70% reduction in codebase complexity (73 → 8-10 services)
- 5x performance improvement through proper indexing and caching
- Professional 2025-standard UI/UX design
- 2-click workspace access (down from 5+ clicks)
- Preserved competitive advantages: 3-tier AI, voice notes, advanced Chrome extension

---

## Pre-Build Requirements: Authentication & Setup Checklist

### Essential Services to Configure Before Starting:

1. **Supabase Setup**
   - Create new Supabase project
   - Get `SUPABASE_URL` and `SUPABASE_ANON_KEY`
   - Configure authentication settings
   - Set up database connection string

2. **Bright Data Configuration**
   - Verify `BRIGHT_DATA_API_KEY` is active
   - Confirm browser credentials: `BRIGHT_DATA_USERNAME`, `BRIGHT_DATA_PASSWORD`
   - Test proxy endpoint: `BRIGHT_DATA_PROXY_ENDPOINT`
   - Verify platform access (Instagram, LinkedIn, etc.)

3. **OpenAI GPT-4.1 Setup**
   - Ensure `OPENAI_API_KEY` supports GPT-4.1 model access
   - Verify rate limits and billing
   - Test GPT-4.1 endpoint availability

4. **Google Cloud Platform (All 8 Services)**
   - Enable APIs in GCP Console:
     * Google Slides API
     * Google Docs API
     * Google Drive API
     * Google Vision API
     * Google Natural Language API
     * BigQuery API
     * Google Sheets API
     * Custom Search API
   - Download service account JSON
   - Set `GOOGLE_API_KEY` or credentials path
   - Verify quotas for each service

5. **Gemini 2.5 Pro**
   - Confirm `GEMINI_API_KEY` supports 2.5 Pro model
   - Test visual analysis capabilities
   - Verify rate limits

6. **Redis/Caching Infrastructure**
   - Set up Redis instance (local or cloud)
   - Configure `REDIS_URL` if using external Redis
   - Or confirm in-memory caching strategy

7. **Additional API Keys**
   - NewsAPI or preferred news service
   - Spotify: `SPOTIFY_CLIENT_ID`, `SPOTIFY_CLIENT_SECRET`
   - TMDB: `TMDB_API_KEY`
   - YouTube Data API (already configured)
   - Reddit API credentials (already configured)

8. **Development Environment**
   - PostgreSQL connection (via Replit or Supabase)
   - Node.js environment variables
   - Chrome browser for extension testing

### Pre-Build Validation Checklist:
- [ ] All API keys are active and tested
- [ ] Database connections verified
- [ ] Google Cloud APIs enabled with proper quotas
- [ ] Bright Data proxy working for target platforms
- [ ] GPT-4.1 model access confirmed
- [ ] Gemini 2.5 Pro visual analysis tested
- [ ] Redis/caching solution ready
- [ ] Development environment configured

---

## Phase 1: Foundation & Architecture (Week 1)

### 1.1 Database Schema Transformation

**From:** 68-column god table with mixed conventions
**To:** 6-table normalized Supabase-compatible schema

```sql
-- New Clean Schema (from Content Radar pattern)
1. users (id, email, first_name, last_name, profile_image_url, created_at, updated_at)
2. projects (id, user_id, name, description, settings, created_at, updated_at)
3. captures (id, project_id, source_url, content, metadata, created_at)
4. briefs (id, project_id, title, content, template_type, created_at, updated_at)
5. brief_captures (brief_id, capture_id, position)
6. content_radar (id, platform, content, engagement_score, viral_score, created_at)
```

**Critical Fixes:**
- Fix ALL snake_case/camelCase inconsistencies
- Add proper indexes on foreign keys and commonly queried fields
- Implement connection pooling (max: 10 connections)
- Add created_at/updated_at timestamps everywhere

### 1.2 Service Consolidation

**Current State:** 73 service files with duplicate functionality
**Target State:** 8-10 clean, focused services

**Consolidation Map:**
```
1. brightDataService.ts (merge 7 files → 1)
   - brightDataBrowser.ts
   - enhancedBrightDataService.ts
   - fixedBrightDataService.ts
   - liveBrightDataService.ts
   - tier2PlatformService.ts
   - contentFetcher.ts
   - strategicIntelligenceService.ts

2. aiAnalysisService.ts (merge 5 files → 1)
   - openai-analysis.ts
   - truthAnalysisEngine.ts
   - truthAnalysisFramework.ts
   - capture-truth-analysis.ts
   - enhancedAIAnalyzer.ts

3. intelligentVisualAnalysisService.ts (NEW - coordinates visual analysis)
   - Routes to Gemini 2.5 Pro for: complex visual understanding, brand analysis, cultural context
   - Routes to Google Vision for: OCR, object detection, logo recognition, text extraction
   - Automatically selects best service based on content type
   - Combines results when both services add value

4. googleIntegrationService.ts (consolidate 8 → 1 unified service)
   - google-slides-service.ts (brief generation)
   - google-docs-service.ts (document export)
   - google-drive-service.ts (storage)
   - google-nlp-service.ts (text analysis)
   - google-bigquery-service.ts (analytics)
   - google-sheets-service.ts (data export)
   - google-custom-search-service.ts (search capabilities)
   - google-vision-service.ts (visual analysis - works WITH Gemini)

5. authService.ts (already clean)
6. briefGenerationService.ts (already clean)
7. chromeExtensionService.ts (already clean)
8. analysisOrchestrator.ts (new - coordinates all analysis)
```

### 1.3 API Cleanup

**News APIs (pick ONE):**
- Keep NewsAPI OR MediaStack (not both)
- Remove redundant: Currents, GNews
- Skip NY Times for now

**Entertainment APIs:**
- Keep: Spotify, TMDB
- Remove: Last.fm (duplicates Spotify)
- Skip: Genius (not core)

### 1.4 Error Handling Standardization

Implement Content Radar's consistent error patterns:
```typescript
// Standard error response
{
  success: false,
  error: {
    code: 'BRIGHT_DATA_ERROR',
    message: 'Failed to fetch content',
    details: 'Rate limit exceeded',
    suggestion: 'Try again in 60 seconds'
  }
}
```

---

## Phase 2: UI/UX Complete Overhaul (Week 2)

### 2.1 Visual Design System

**Color Palette (2025 Standards):**
```css
:root {
  /* Primary */
  --primary-blue: #0066FF;
  --primary-hover: #0052CC;
  
  /* Secondary */
  --ai-purple: #6B46C1;
  --ai-purple-light: #8B66E1;
  
  /* Neutrals */
  --gray-950: #111827;
  --gray-900: #1F2937;
  --gray-800: #374151;
  --gray-700: #4B5563;
  --gray-600: #6B7280;
  --gray-500: #9CA3AF;
  --gray-400: #D1D5DB;
  --gray-300: #E5E7EB;
  --gray-200: #F3F4F6;
  --gray-100: #F9FAFB;
  --white: #FFFFFF;
  
  /* Semantic */
  --success: #10B981;
  --warning: #F59E0B;
  --error: #EF4444;
  
  /* Dark Mode (default) */
  --bg-primary: var(--gray-950);
  --bg-secondary: var(--gray-900);
  --text-primary: var(--gray-100);
  --text-secondary: var(--gray-400);
}
```

**Typography System:**
```css
/* Modern, Clean Typography */
--font-sans: 'Inter', -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
--font-mono: 'SF Mono', Monaco, Consolas, monospace;

/* Size Scale (minimum 14px body) */
--text-xs: 0.75rem;   /* 12px - use sparingly */
--text-sm: 0.875rem;  /* 14px - minimum body */
--text-base: 1rem;    /* 16px - standard body */
--text-lg: 1.125rem;  /* 18px */
--text-xl: 1.25rem;   /* 20px */
--text-2xl: 1.5rem;   /* 24px */
--text-3xl: 1.875rem; /* 30px */
--text-4xl: 2.25rem;  /* 36px */

/* Line Heights */
--leading-tight: 1.25;
--leading-normal: 1.5;
--leading-relaxed: 1.75;
```

**Spacing System (8pt Grid):**
```css
/* Consistent 8-point grid */
--space-1: 0.5rem;   /* 8px */
--space-2: 1rem;     /* 16px */
--space-3: 1.5rem;   /* 24px */
--space-4: 2rem;     /* 32px */
--space-5: 2.5rem;   /* 40px */
--space-6: 3rem;     /* 48px */
--space-8: 4rem;     /* 64px */
--space-10: 5rem;    /* 80px */
```

### 2.2 Navigation Redesign

**New Navigation Structure:**
```
┌─────────────────────────────┐
│ [◐] Content Radar          │ ← Collapsible to icons
├─────────────────────────────┤
│ 🏠 Intelligence Hub        │ ← Renamed from "Today's Briefing"
│ 📊 My Workspaces          │ ← PRIMARY - 2-click access
│ ⚡ Quick Capture          │ ← Streamlined capture
│ 🎯 Brief Builder          │ ← Simplified name
│ 🔍 Explore Signals        │ ← Discovery interface
│ ⚙️ Settings              │ ← System management
└─────────────────────────────┘

Width: 240px expanded, 64px collapsed
```

**Mobile Navigation (Bottom Tab Bar):**
```
┌─────────────────────────────┐
│       [Content Area]        │
├─────────────────────────────┤
│  🏠   📊   ⚡   🎯   ⚙️  │ ← Fixed bottom, 64px height
└─────────────────────────────┘
```

### 2.3 Dashboard Redesign (Intelligence Hub)

**Grid Layout:**
```
┌─────────────┬─────────────┬─────────────┐
│ AI Insights │ Trending    │ Your Impact │
│ Summary     │ Signals     │ Metrics     │
│ h: 200px    │ (live)      │ (charts)    │
├─────────────┴─────────────┴─────────────┤
│     Active Workspaces Gallery            │
│     (Pinterest-style cards)              │
│     3 columns desktop, 1 mobile          │
├─────────────┬─────────────┬─────────────┤
│ Recent      │ Pending     │ Quick       │
│ Captures    │ Analysis    │ Actions     │
│ (list)      │ (queue)     │ (buttons)   │
└─────────────┴─────────────┴─────────────┘
```

**Card Design Standards:**
```css
.dashboard-card {
  background: var(--bg-secondary);
  border-radius: 12px;
  padding: var(--space-3);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: all 200ms ease;
}

.dashboard-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}
```

### 2.4 Workspace Experience

**Pinterest-Style Workspace Cards:**
```
┌─────────────────┐
│ [Project Image] │ ← Latest capture thumbnail
│                 │
│ Project Name    │
│ ━━━━━━━━━○     │ ← Progress ring
│                 │
│ 📄 24 captures │
│ ✅ 18 analyzed │
│ 🕐 2 hours ago │
│                 │
│ [Open Workspace]│ ← Primary CTA
└─────────────────┘
```

**Workspace Interior:**
- Kanban board for capture management
- Split view: captures left, analysis right
- Floating action button (FAB) for quick capture
- AI assistant chat in bottom-right

### 2.5 Component Library

**Button Hierarchy:**
```css
/* Primary - Main actions */
.btn-primary {
  background: var(--primary-blue);
  color: white;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 500;
  min-height: 44px; /* Touch-friendly */
}

/* Secondary - Supporting actions */
.btn-secondary {
  background: transparent;
  border: 2px solid var(--gray-700);
  color: var(--text-primary);
}

/* Tertiary - Minor actions */
.btn-tertiary {
  background: transparent;
  color: var(--primary-blue);
  text-decoration: underline;
}
```

**Form Design:**
- Floating labels for space efficiency
- Real-time validation with inline errors
- Clear focus states (2px blue outline)
- Loading states for all inputs

### 2.6 Data Visualization

**Chart Standards:**
- Line charts for trends (max 7 series)
- Bar charts for comparisons
- Donut charts for percentages (not pie)
- Consistent color palette
- Interactive tooltips
- Export functionality

---

## Phase 3: Core Feature Implementation (Week 3)

### 3.1 Preserve Competitive Advantages

**Keep These Unique Features:**
1. **3-Tier AI System**
   - Quick Mode: GPT-4.1-mini or GPT-3.5-turbo (2-4 sentences)
   - Standard Mode: GPT-4.1 (4-7 sentences)
   - Deep Mode: GPT-4.1 extended context
   - Bidirectional caching between modes

2. **Advanced Chrome Extension**
   - Voice notes with Whisper transcription
   - Screen selection tools (LeoLime-inspired)
   - 10 strategic tags with auto-tagging
   - 24-hour session memory
   - Keyboard shortcuts

3. **Broader Platform Coverage**
   - LinkedIn (B2B insights)
   - Multiple news sources
   - Entertainment APIs (Spotify, TMDB)

4. **Advanced Features**
   - Comment mining system
   - Workspace management
   - Mobile-first responsive design

### 3.2 Analysis Orchestrator Pattern

Create central orchestration service:
```typescript
class AnalysisOrchestrator {
  async analyzeCapture(capture: Capture) {
    // 1. Extract metadata
    const metadata = await this.extractMetadata(capture);
    
    // 2. Run AI analysis based on tier
    const analysis = await this.runTieredAnalysis(capture, metadata);
    
    // 3. Visual analysis if needed
    if (capture.hasVisuals) {
      analysis.visual = await this.geminiService.analyze(capture);
    }
    
    // 4. Cache results
    await this.cacheService.store(analysis);
    
    return analysis;
  }
}
```

### 3.3 Simplified API Integration

**Final Service Count: 8-10 total**
1. Authentication Service
2. Bright Data Service (unified)
3. AI Analysis Service (OpenAI consolidated)
4. Gemini Visual Service
5. Google Integration Service (Slides, Docs, Drive only)
6. Chrome Extension Service
7. Brief Generation Service
8. Analysis Orchestrator
9. News API Service (one provider)
10. Entertainment API Service (Spotify + TMDB)

---

## Phase 4: Performance & Polish (Week 4)

### 4.1 Performance Optimizations

**From Content Radar's Success:**
- Connection pooling (max: 10)
- Strategic indexes on all foreign keys
- Parallel processing by default
- CDN for all media files
- Lazy loading components
- Code splitting

**Keep Your Advantages:**
- Advanced Redis caching
- Multi-level cache strategy
- Request deduplication

### 4.2 Mobile Optimization

**Responsive Breakpoints:**
```css
/* Mobile First Approach */
/* Base: Mobile < 768px */
/* Tablet: 768px - 1024px */
@media (min-width: 768px) { }
/* Desktop: > 1024px */
@media (min-width: 1024px) { }
```

**Mobile-Specific Features:**
- Touch-optimized buttons (44px minimum)
- Swipe gestures for navigation
- Bottom tab bar navigation
- Safe area support for notches
- Reduced motion options

### 4.3 AI-Powered UX Features

**Smart Personalization:**
- Adaptive dashboard based on usage
- Predictive navigation preloading
- Contextual tooltips for new users
- Workflow suggestions

**Natural Language Features:**
- Command palette (Cmd+K)
- Voice commands via Chrome extension
- Natural language filtering

### 4.4 Micro-interactions & Polish

**Subtle Animations:**
```css
/* Standard transition timing */
.transition-all {
  transition: all 200ms cubic-bezier(0.4, 0, 0.2, 1);
}

/* Loading states */
.skeleton {
  background: linear-gradient(
    90deg,
    var(--gray-800) 25%,
    var(--gray-700) 50%,
    var(--gray-800) 75%
  );
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
}
```

**Empty States:**
- Illustrative graphics
- Clear CTAs
- Helpful context
- Progress indicators

---

## Phase 5: Testing & Launch Preparation (Week 5)

### 5.1 Testing Framework

**Add Basic Testing:**
```json
// package.json
"scripts": {
  "test": "jest",
  "test:e2e": "cypress run",
  "test:coverage": "jest --coverage"
}
```

**Priority Tests:**
1. Authentication flow
2. Capture → Analysis pipeline
3. Chrome extension integration
4. API error handling
5. Mobile responsiveness

### 5.2 Migration Strategy

**Side-by-Side Approach (from Content Radar):**
1. Build new system alongside old
2. Migrate feature by feature
3. Test each migration thoroughly
4. Maintain data integrity
5. Zero downtime deployment

### 5.3 Documentation Updates

**Update replit.md with:**
- New architecture decisions
- Service consolidation map
- UI/UX design system
- Performance improvements
- Migration timeline

---

## Phase 6: Post-Launch Optimization (Weeks 6-8)

### 6.1 Performance Monitoring

**Key Metrics:**
- Page load time < 2 seconds
- API response time < 200ms
- Chrome extension capture < 1 second
- Analysis processing < 5 seconds

### 6.2 User Feedback Integration

**Feedback Channels:**
- In-app feedback widget
- Chrome extension ratings
- User interviews
- Analytics tracking

### 6.3 Continuous Improvement

**Monthly Reviews:**
- Performance metrics
- User feedback analysis
- Feature usage statistics
- Cost optimization

---

## Success Metrics

### Technical Metrics
- **Code Reduction**: 73 → 10 services (86% reduction)
- **Performance**: 5x faster queries with proper indexing
- **Reliability**: 99.9% uptime with error handling
- **Cost**: 70% reduction in API costs through caching

### User Experience Metrics
- **Navigation**: 5+ clicks → 2 clicks for workspace access
- **Mobile Usage**: 40%+ of users on mobile
- **Chrome Extension**: 80%+ adoption rate
- **Time to Value**: < 2 minutes to first capture

### Business Metrics
- **User Activation**: 50%+ complete first analysis
- **Retention**: 70%+ weekly active users
- **Engagement**: 10+ captures per user per week
- **Brief Generation**: 2+ briefs per user per month

---

## Risk Mitigation

### Technical Risks
- **Migration Failures**: Use side-by-side approach
- **Data Loss**: Comprehensive backups before each phase
- **Performance Issues**: Load testing before launch
- **API Limits**: Implement proper rate limiting

### User Risks
- **Learning Curve**: Progressive disclosure, tooltips
- **Feature Loss**: Maintain all valuable features
- **Workflow Disruption**: Clear migration communication

---

## Timeline Summary

**Total Duration: 6-8 weeks**

- **Week 1**: Foundation & Architecture
- **Week 2**: UI/UX Overhaul
- **Week 3**: Core Feature Implementation
- **Week 4**: Performance & Polish
- **Week 5**: Testing & Launch Prep
- **Weeks 6-8**: Optimization & Refinement

---

## Conclusion

This comprehensive rebuild plan transforms a complex, unwieldy system into a clean, professional platform while preserving all competitive advantages. By following Content Radar's successful patterns while maintaining our unique features, we create a best-in-class content intelligence platform ready for 2025 and beyond.

The key is disciplined execution: consolidate ruthlessly, design thoughtfully, and always prioritize user experience over technical complexity.