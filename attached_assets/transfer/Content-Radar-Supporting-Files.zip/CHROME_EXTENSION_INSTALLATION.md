# Chrome Extension Installation Guide

## Quick Installation Steps

1. **Open Chrome Extensions Page**
   - Go to `chrome://extensions/` in your Chrome browser
   - Or click the 3-dot menu → More tools → Extensions

2. **Enable Developer Mode**
   - Toggle the "Developer mode" switch in the top right corner

3. **Load the Extension**
   - Click "Load unpacked"
   - Navigate to the `chrome-extension` folder in your project
   - Select the folder and click "Select"

4. **Verify Installation**
   - You should see "Content Radar - Strategic Intelligence" in your extensions list
   - The extension icon should appear in your toolbar
   - If not visible, click the puzzle piece icon and pin Content Radar

## Testing the Extension

### Quick Capture (Ctrl+Shift+C / Cmd+Shift+C)
- Navigate to any webpage
- Press the shortcut to capture the current page
- Check the popup for capture status

### Screen Selection (Ctrl+Shift+S / Cmd+Shift+S)
- Press the shortcut to activate selection mode
- Click and drag to select an area
- Release to capture the selection

### Voice Notes (Ctrl+Shift+V / Cmd+Shift+V)
- Press the shortcut to start recording
- Speak your note
- Press again to stop and save

### Popup Interface
- Click the extension icon to open the popup
- Select a project from the dropdown
- Enter a URL or use quick capture
- View recent captures and their analysis

## Troubleshooting

**Extension not loading?**
- Check for errors in chrome://extensions/
- Make sure all files are present in chrome-extension folder
- Try reloading the extension

**API connection issues?**
- Ensure the backend server is running on http://localhost:5000
- Check if you're logged in to the main application
- Open DevTools on the extension popup to see error messages

**Keyboard shortcuts not working?**
- Check chrome://extensions/shortcuts
- Make sure shortcuts aren't conflicting with other extensions
- Try setting custom shortcuts if needed