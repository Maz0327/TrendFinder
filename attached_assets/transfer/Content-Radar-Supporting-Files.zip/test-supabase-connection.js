// Test Supabase connection
import pkg from 'pg';
const { Pool } = pkg;

async function testSupabaseConnection() {
  console.log('Testing Supabase connection...');
  
  try {
    // Extract from the full connection string
    const connectionString = "postgresql://postgres:kbx4wey3fpa_myw8RWK@db.uytiwodjtulpjvgjtsod.supabase.co:5432/postgres";
    
    // Parse the connection string to get Supabase URL and key
    const url = connectionString.match(/db\.(.+?)\.supabase\.co/)[0];
    const projectRef = connectionString.match(/db\.(.+?)\.supabase\.co/)[1];
    
    const supabaseUrl = `https://${projectRef}.supabase.co`;
    console.log('Supabase URL:', supabaseUrl);
    console.log('Project Ref:', projectRef);
    
    // Test basic connection with anon key (we need the actual anon key)
    console.log('⚠️  Need SUPABASE_ANON_KEY for client connection');
    console.log('   Database password:', 'kbx4wey3fpa_myw8RWK');
    console.log('   Connection string provided ✅');
    
    // Try direct database connection test
    const pool = new Pool({
      connectionString: connectionString,
      ssl: { rejectUnauthorized: false }
    });
    
    const client = await pool.connect();
    console.log('✅ Direct PostgreSQL connection successful');
    
    // Test basic query
    const result = await client.query('SELECT current_database(), current_user, version()');
    console.log('Database:', result.rows[0].current_database);
    console.log('User:', result.rows[0].current_user);
    console.log('Version:', result.rows[0].version.split(' ')[0]);
    
    // Check if this is a Supabase instance
    const authCheck = await client.query(`
      SELECT EXISTS (
        SELECT 1 FROM information_schema.tables 
        WHERE table_schema = 'auth' AND table_name = 'users'
      ) as has_auth_users
    `);
    
    console.log('Supabase auth tables:', authCheck.rows[0].has_auth_users ? 'Found ✅' : 'Not found');
    
    client.release();
    await pool.end();
    
    return true;
    
  } catch (error) {
    console.log('❌ Supabase connection failed:', error.message);
    return false;
  }
}

testSupabaseConnection().catch(console.error);