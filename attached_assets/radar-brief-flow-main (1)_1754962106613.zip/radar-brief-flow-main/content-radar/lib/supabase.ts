// Re-export the existing env-based Supabase client for content-radar
export { IS_DEMO, getClient, supabase } from "../../client/src/lib/supabaseClient";
