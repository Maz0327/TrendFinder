const PlatformFilter = () => null
export default PlatformFilter
