import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/providers/AuthProvider";
import { Link, useLocation } from "wouter";
import { LogIn, Mail, Lock, UserPlus } from "lucide-react";

const updateSEO = (title: string, description: string) => {
  document.title = title;
  const desc = document.querySelector('meta[name="description"]');
  if (desc) {
    desc.setAttribute("content", description);
  } else {
    const m = document.createElement("meta");
    m.name = "description";
    m.content = description;
    document.head.appendChild(m);
  }
  let canonical = document.querySelector("link[rel=canonical]") as HTMLLinkElement | null;
  if (!canonical) {
    canonical = document.createElement("link");
    canonical.rel = "canonical";
    document.head.appendChild(canonical);
  }
  canonical.href = `${window.location.origin}/auth`;
};

export default function Auth() {
  const { signIn, signUp, session } = useAuth();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    updateSEO(
      "Login or Sign Up | TrendFinder",
      "Access TrendFinder: secure login and signup to your content intelligence dashboard"
    );
  }, []);

  useEffect(() => {
    if (session) setLocation("/");
  }, [session, setLocation]);

  const title = useMemo(() => (mode === "signin" ? "Welcome back" : "Create your account"), [mode]);
  const buttonIcon = mode === "signin" ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />;
  const ctaText = mode === "signin" ? "Sign In" : "Sign Up";

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (mode === "signin") {
        const { error } = await signIn(email, password);
        if (error) {
          toast({ title: "Sign in failed", description: error, variant: "destructive" });
        } else {
          toast({ title: "Signed in", description: "Welcome back!" });
          setLocation("/");
        }
      } else {
        const { error } = await signUp(email, password);
        if (error) {
          toast({ title: "Sign up failed", description: error, variant: "destructive" });
        } else {
          toast({ title: "Check your email", description: "We sent you a confirmation link." });
          setMode("signin");
        }
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-subtle flex items-center justify-center p-6">
      <main className="w-full max-w-md">
        <Card className="shadow-glow bg-card/90 backdrop-blur">
          <CardHeader className="space-y-2 text-center">
            <CardTitle className="text-2xl text-foreground">{title}</CardTitle>
            <CardDescription className="text-muted-foreground">
              {mode === "signin" ? "Sign in to continue to your dashboard" : "Start monitoring trends with a new account"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-foreground">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-foreground">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    autoComplete={mode === "signin" ? "current-password" : "new-password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
              <Button type="submit" disabled={submitting} className="w-full">
                {buttonIcon}
                <span className="ml-2">{ctaText}</span>
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex flex-col gap-3">
            {mode === "signin" ? (
              <p className="text-sm text-muted-foreground text-center">
                Don't have an account?{" "}
                <button
                  className="text-primary underline-offset-4 hover:underline"
                  onClick={() => setMode("signup")}
                >
                  Create one
                </button>
              </p>
            ) : (
              <p className="text-sm text-muted-foreground text-center">
                Already have an account?{" "}
                <button
                  className="text-primary underline-offset-4 hover:underline"
                  onClick={() => setMode("signin")}
                >
                  Sign in
                </button>
              </p>
            )}
            <p className="text-xs text-muted-foreground text-center">
              By continuing you agree to our <Link href="/terms" className="text-primary underline-offset-4 hover:underline">Terms</Link>
              {" "}and <Link href="/privacy" className="text-primary underline-offset-4 hover:underline">Privacy Policy</Link>.
            </p>
          </CardFooter>
        </Card>
      </main>
    </div>
  );
}
