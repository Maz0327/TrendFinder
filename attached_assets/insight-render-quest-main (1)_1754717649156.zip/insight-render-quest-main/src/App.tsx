import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Switch, Route, useLocation } from "wouter";
import { useEffect } from "react";

import Index from "./pages/Index";
import Explore from "./pages/Explore";
import Capture from "./pages/Capture";
import Trends from "./pages/Trends";
import Projects from "./pages/Projects";
import StrategicLab from "./pages/StrategicLab";
import Insights from "./pages/Insights";
import Search from "./pages/Search";
import NotFound from "./pages/NotFound";
import ExtensionPreview from "./pages/ExtensionPreview";
import Auth from "./pages/Auth";
import { AuthProvider, useAuth } from "./providers/AuthProvider";

const queryClient = new QueryClient();

function AppRoutes() {
  const { session, loading } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    if (loading) return;
    if (!session && location !== "/auth") setLocation("/auth");
    if (session && location === "/auth") setLocation("/");
  }, [session, loading, location, setLocation]);

  return (
    <Switch>
      <Route path="/auth" component={Auth} />
      <Route path="/" component={Index} />
      <Route path="/explore" component={Explore} />
      <Route path="/capture" component={Capture} />
      <Route path="/trends" component={Trends} />
      <Route path="/projects" component={Projects} />
      <Route path="/lab" component={StrategicLab} />
      <Route path="/insights" component={Insights} />
      <Route path="/search" component={Search} />
      <Route path="/extension-preview" component={ExtensionPreview} />
      <Route component={NotFound} />
    </Switch>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
